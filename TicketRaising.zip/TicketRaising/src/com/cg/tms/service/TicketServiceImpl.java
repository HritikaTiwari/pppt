package com.cg.tms.service;

import java.util.List;
import java.util.Random;

import com.cg.tms.dao.TicketDao;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService {
	private static TicketDao dao = new TicketDaoImpl();

	@Override
	public int raiseNewTicket(TicketBean ticketBean) {
		int ticketNo = new Random().nextInt(2000);
		ticketBean.setTicketNo(ticketNo);
		int ticketNum = dao.raiseNewTicket(ticketBean);
		return ticketNum;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		return dao.listTicketCategory();
	}

}
