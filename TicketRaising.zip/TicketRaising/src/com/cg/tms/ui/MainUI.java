package com.cg.tms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	private static TicketService service = new TicketServiceImpl();

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("*********************Menu*****************\r\n" + "1. Raise a Ticket\r\n" +

					"2. Exit");
			int choice = scan.nextInt();
			switch (choice) {
			case 1:
				System.out.println("*********************Ticket Category*****************\r\n"
						+ "1. Software Installation\r\n" + "2. MailBox creation\r\n" + "3. Network Issue");
				System.out.print("Enter option : ");

				TicketCategory tc = null;
				int issueId = scan.nextInt();
				List<TicketCategory> list = service.listTicketCategory();
				switch (issueId) {
				case 1:
					tc = list.get(0);
					break;
				case 2:
					tc = list.get(1);
					break;
				case 3:
					tc = list.get(2);
					break;
				default:
					System.exit(0);
				}
				scan.nextLine();
				System.out.print("Enter DESCRIPTION RELATED TO ISSUE :");
				String desc = scan.nextLine();
				System.out.print("Enter priority 1.low 2.medium 3.high: ");
				int priority = scan.nextInt();
				String ticketPriority = null;
				switch (priority) {
				case 1:
					ticketPriority = "low";
					break;
				case 2:
					ticketPriority = "medium";
					break;
				case 3:
					ticketPriority = "high";
					break;
				default:
					System.exit(0);
				}
				 TicketBean ticket1 = new TicketBean(0, tc, desc, ticketPriority,null);
				int ticketNo = service.raiseNewTicket(ticket1);
				 System.out.println(ticketNo);
				break;
			case 2:
				System.exit(0);
			default:
				System.out.println("Please enter correct choice.");
				
				

			}
			scan.close();

		}
	}
}
