import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http: HttpClient;
  employee: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
    this.fetchEmployee();
  }
  fetched: boolean = false;
  fetchEmployee() {
    this.http.get('./assets/employee.json')
      .subscribe(
        data => {
          if (!this.fetched) {
            this.convert(data);
            this.fetched = true;
          }
        });
  }
  convert(data: any) {
    for (let o of data) {
      let e = new Employee(o.Id, o.Name, o.Price, o.Category);
      this.employee.push(e);
    }
  }
  getEmployee(){
    return this.employee;
  }
  delete (Id: number)
{
  let foundIndex: number = -1;
  for (let i = 0; i < this.employee.length; i++) {
    let e = this.employee[i];
    if (Id == e.Id) {
      foundIndex = i;
      break;
    }
  }

  this.employee.splice(foundIndex, 1);
}
// search(Id:number):Employee
// {
//   var name:string;
//  var flag=0;
//   for (let i = 0; i < this.employee.length; i++) {
  
//     if (Id == this.employee[i].Id) {
//       var arr=this.employee[i];
      
//      flag=1;
//       break;
//     }
//   }
//   if(flag==0){
//     alert(Id+"invalid id");
//   }
//   else{
//     console.log(arr)
//     return arr;
//   }

search(str:string):Employee[]
{
  let e:Employee[]=[];
  
 var flag=0;
  for (let i = 0; i < this.employee.length; i++) {
  
    if (str == this.employee[i].Name || str== this.employee[i].Category ) {
         e.push(this.employee[i]);
      console.log(e);
     flag=1;
    
    }
  }
  if(flag==0){
    alert(str+"invalid Name or Category");
  }
  else{
    console.log(e);
   // return arr;
   return e;
  } 
}
}
export class Employee {

  Id: number;
  Name: string;
  Price: number;
  Category: string;
  constructor(Id: number,Name: string,  Price: number, Category: string) {
    this.Id = Id;
    this.Name = Name;
    this.Price = Price;
    this.Category = Category;
    
  }
}
