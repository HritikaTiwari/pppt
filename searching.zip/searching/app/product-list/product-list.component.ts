import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee } from '../my-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  column: string = 'Id';
  employee: Employee[] = [];
  order: boolean = true;
  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
  }
  
  delete(Id: number) {
    this.service.delete(Id);
    this.employee = this.service.getEmployee();
  }
 

  ngOnInit() {
    this.service.fetchEmployee();
    this.employee = this.service.getEmployee();
  }

}
