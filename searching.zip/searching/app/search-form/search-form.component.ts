import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee } from '../my-service.service';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {

  service:MyServiceService;
  constructor(service:MyServiceService) {
    this.service=service;
   }
 
  ngOnInit() {
  }
  info:Employee[]=[];
  Id:number;
Name:string;
Price:number; 
Category:string;

  search(data:any){
    let str:string=data.str;
    this.info=this.service.search(str);
    
    // let Id:number=data.Id;
    // this.info=this.service.search(Id);
    // this.Id=this.info.Id;
    //  this.Name=this.info.Name;
    //  this.Price=this.info.Price;
    //  this.Category=this.info.Category;
    
  }

}

 
  
