import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RetrieveComponent } from './retrieve/retrieve.component';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http: HttpClient;
  employee: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
  }
  fetched: boolean = false;
  fetchEmployee() {
    this.http.get('./assets/employee.json')
      .subscribe(
        data => {
          if (!this.fetched) {
            this.convert(data);
            this.fetched = true;
          }
        });
  }
  getEmployee(): Employee[] {
    return this.employee;
  }
  convert(data: any) {
    for (let o of data) {
      let e = new Employee(o.ename, o.eid, o.edesignation, o.eaddress, o.econtact, o.egender);
      this.employee.push(e);
    }
  }
  add(e: Employee) {

    this.employee.push(e);
  }
 update(e: Employee) {
   this.delete(e['eid']);
  this.employee.push(e);
 }
  delete (eid: number)
{
  let foundIndex: number = -1;
  for (let i = 0; i < this.employee.length; i++) {
    let e = this.employee[i];
    if (eid == e.eid) {
      foundIndex = i;
      break;
    }
  }

  this.employee.splice(foundIndex, 1);
}
retrieve(eid:number):string
{
  var name:string;
 var flag=0;
  for (let i = 0; i < this.employee.length; i++) {
  
    if (eid == this.employee[i].eid) {
      name=this.employee[i].ename;
     flag=1;
      break;
    }
  }
  if(flag==0)
alert(eid+"invalid id");
  return name;
}
}


// retrieve(eid:number)
// {
//   var name:string;
//  var flag=0;
//   for (let i = 0; i < this.employee.length; i++) {
  
//     if (eid == this.employee[i].eid) {
//       var emp =this.employee[i];
//      flag=1;
//       break;
//     }
//   }
//   if(flag==0)
//   //alert(eid+"invalid id");
//   return emp;
// }



export class Employee {
  ename: string;
  eid: number;

  edesignation: string;
  eaddress: string;
  econtact: number;
  egender: string;
  constructor(ename: string, eid: number, edesignation: string, eaddress: string, econtact: number, egender: string) {
    this.ename = ename;
    this.eid = eid;

    this.edesignation = edesignation;
    this.eaddress = eaddress;
    this.econtact = econtact;
    this.egender = egender;
  }
}
