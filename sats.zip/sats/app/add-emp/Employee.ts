export class Employee
{
    ename:string;
    eid:number;
    edesignation:string;
    eaddress:string;
    econtact:number;
    egender:string;
  
}