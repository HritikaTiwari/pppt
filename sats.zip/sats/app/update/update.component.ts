import { Component, OnInit } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  createdEmployee:Employee;
  createdFlag:boolean=false;
  service:MyserviceService;
    constructor(service:MyserviceService) {
      this.service=service;
     }
  
    ngOnInit() {
      
    }
    
    add(data:any){
      this.createdEmployee=new Employee(data.ename,data.eid, data.edesignation,data.eaddress,data.econtact,data.egender);
      this.service.update(this.createdEmployee);
      this.createdFlag=true;
    }

}
