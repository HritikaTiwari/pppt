import { Component, OnInit } from '@angular/core';

import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-retrieve',
  templateUrl: './retrieve.component.html',
  styleUrls: ['./retrieve.component.css']
})
export class RetrieveComponent implements OnInit {
  // retrieveEmployee:Employee;
 
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
   }
  //  retrieveFlag:boolean=false;
  ngOnInit() {
  }
name:string;
  
  retrieve(data:any){
    let eid:number=data.eid;
    this.name=this.service.retrieve(eid);
    //this.service.retrieve(data.ename);
    // this.retrieveFlag=true;
  }

}

 
  