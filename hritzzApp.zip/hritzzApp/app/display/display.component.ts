import { Component, OnInit, Input } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';



@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  column: string = 'eid';
  employee: Employee[] = [];
  order: boolean = true;
  service: MyserviceService;
  constructor(service: MyserviceService) {
    this.service = service;
  }
  delete(eid: number) {
    this.service.delete(eid);
    this.employee = this.service.getEmployee();
  }
  ngOnInit() {
    this.service.fetchEmployee();
    this.employee = this.service.getEmployee();
  }
  sort(column:string)
  {
    if(this.column == column)
    {
      this.order = ! this.order;
    }
    else
    {
      this.column = column;
      this.order = true;
    }
  }

}
