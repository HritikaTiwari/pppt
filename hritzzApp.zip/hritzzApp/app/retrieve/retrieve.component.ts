import { Component, OnInit } from '@angular/core';

import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-retrieve',
  templateUrl: './retrieve.component.html',
  styleUrls: ['./retrieve.component.css']
})
export class RetrieveComponent implements OnInit {
  // retrieveEmployee:Employee;
 
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
   }
  //  retrieveFlag:boolean=false;
  ngOnInit() {
  }
  info:Employee;
name:string;
des:string; 
addr:string;
cont:number;
gen:string;
  retrieve(data:any){
    let eid:number=data.eid;
    this.info=this.service.retrieve(eid);
     this.name=this.info.ename;
     this.des=this.info.edesignation;
     this.addr=this.info.eaddress;
     this.cont=this.info.econtact;
     this.gen=this.info.egender;
    
    // this.name=this.service.retrieve(eid);
    // this.name=this.service.retrieve(eid);
    // this.name=this.service.retrieve(eid);
    //this.service.retrieve(data.ename);
    // this.retrieveFlag=true;
  }

}

 
  