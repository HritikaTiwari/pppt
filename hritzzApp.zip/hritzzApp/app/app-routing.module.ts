import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { DisplayComponent } from './display/display.component';

import { DataComponent } from './data/data.component';
import { UpdateComponent } from './update/update.component';
import { RetrieveComponent } from './retrieve/retrieve.component';
const routes: Routes = [
{
  path:'app-add-emp',
  component:AddEmpComponent
},
{
  path:'app-display',
  component:DisplayComponent
},
{
  path:'app-data',
  component:DataComponent
}
,
{
  path:'app-update',
  component:UpdateComponent
}
,
{
  path:'app-retrieve',
  component:RetrieveComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
