import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';
@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
data;
service:DataService;
  constructor( service:DataService) {
    this.service=service;
 }
 
  ngOnInit() {
    this.service.fetchData();
    this.data=this.service.getData();
  }
}
