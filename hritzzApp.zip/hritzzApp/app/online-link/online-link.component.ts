import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-link',
  templateUrl: './online-link.component.html',
  styleUrls: ['./online-link.component.css']
})
export class OnlineLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
