import { Component, OnInit, Input } from '@angular/core';
import { Employee,MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {
  createdEmployee:Employee;
  createdFlag:boolean=false;
  service:MyserviceService;
    constructor(service:MyserviceService) {
      this.service=service;
     }
  
    ngOnInit() {}
    
    add(data:any){
      this.createdEmployee=new Employee(data.ename,data.eid, data.edesignation,data.eaddress,data.econtact,data.egender);
      this.service.add(this.createdEmployee);
      this.createdFlag=true;
    }
  
  }