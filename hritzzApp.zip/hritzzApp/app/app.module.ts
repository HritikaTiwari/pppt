import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpComponent } from './emp/emp.component';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { DisplayComponent } from './display/display.component';

import { MyserviceService } from './myservice.service';
import { OnlineLinkComponent } from './online-link/online-link.component';
import { DataComponent } from './data/data.component';
import { OrderbyPipe } from './orderby.pipe';
import { UpdateComponent } from './update/update.component';
import { RetrieveComponent } from './retrieve/retrieve.component';




@NgModule({
  declarations: [
    AppComponent,
    EmpComponent,
   
    AddEmpComponent,
    DisplayComponent,
    OnlineLinkComponent,
    DataComponent,
    OrderbyPipe,
    UpdateComponent,
    RetrieveComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
