import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  http: HttpClient;
  data =[];
  constructor(http: HttpClient) {
    this.http = http;
  }
  fetched: boolean = false;
  fetchData() {
    this.http.get('https://reqres.in/api/users?page=2')
      .subscribe(
        data => {
          if (!this.fetched) {
            this.convert(data);
            this.fetched = true;
          }
        });
  }
  getData(){
    return this.data;
  }
  convert(data: any) {
    for (let o of data['data']) {
      this.data.push(o);
    }
  }
}
