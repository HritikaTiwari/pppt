package cpg.service;

import cpg.bean.Account;
import cpg.dao.AccountDao;
import cpg.dao.AccountDaoImpl;
import cpg.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	private static AccountDao dao = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) throws AccountException {
		Account account = dao.getAccountDetails(mobileNo);
		if (account == null) {
			throw new AccountException("No account found for " + mobileNo);
		}
		return account;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountException {
		int balance = dao.rechargeAccount(mobileNo, rechargeAmount);
		return balance;
	}

}
