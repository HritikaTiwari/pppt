package cpg.service;

import cpg.bean.Account;
import cpg.exception.AccountException;

public interface AccountService {
	Account getAccountDetails(String mobileNo) throws AccountException;
	int rechargeAccount(String mobileNo,double rechargeAmount) throws AccountException;
}
