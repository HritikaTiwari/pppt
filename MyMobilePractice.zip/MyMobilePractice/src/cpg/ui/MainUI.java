package cpg.ui;

import java.util.Scanner;

import cpg.bean.Account;
import cpg.exception.*;
import cpg.service.AccountService;
import cpg.service.AccountServiceImpl;
import cpg.util.Util;

public class MainUI {
	private static AccountService service = new AccountServiceImpl();

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		char run = 'y';
		while (run == 'y' || run == 'Y') {
			System.out.println("*********************Global Recruitments*****************\r\n"
					+ "1. Account Balance Enquiry\r\n" + "2. Recharge Account\r\n" + "3. Exit");
			String choice = scan.nextLine();
			// long rechargeAmount = service.rechargeAccount(mobileNo, rechargeAmount);
			switch (choice) {
			case "1":
				try {
					System.out.println("Mobile No: ");
					String mobileNo = scan.nextLine();
					Util.validateMobile(mobileNo);
					Account account = service.getAccountDetails(mobileNo);

					System.out.println("Your Current Balance is : " + account.getAccountBalance());
				} catch (AccountException e) {
					System.out.println(e.getMessage());
				} catch (Exception e) {
					System.out.println("Something went wrong!");
				}
				break;
			case "2":

				try {
					System.out.println("Enter Mobile No: ");
					String mobileNo1 = scan.nextLine();
					Util.validateMobile(mobileNo1);
					System.out.println("Enter Recharge Amount: ");
					long amount = scan.nextLong();
					Util.validateAmount(amount);
					// Account account1 = service.getAccountDetails(mobileNo1);
					// double rechargeAmount1 = account1.getAccountBalance();
					long rechargeAccount = service.rechargeAccount(mobileNo1, amount);

					System.out.println("Hello " + service.getAccountDetails(mobileNo1).getCustomerName()
							+ " Available Balance is : " + rechargeAccount);
				} catch (AccountException e) {
					System.out.println(e.getMessage());
				} catch (Exception e) {
					System.out.println("Something went wrong!");
				}
				break;
			case "3":
				System.exit(0);
				System.out.println("Thank you for using our service.");
			default:
				System.out.println("Please enter a valid choice.");
				continue;
					
			}
			System.out.println("\nDo you want to continue? (y/n)......");
			run = scan.next().charAt(0);
		}
		scan.close();

	}
}
