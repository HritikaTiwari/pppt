package cpg.util;

import cpg.exception.AccountException;

public class Util {
	public static void validateMobile(String mobileNo ) throws AccountException {
		String regEx = "[7-9][0-9]{9}";
		if(!mobileNo.matches(regEx)) {
			throw new AccountException("Enter Valid Number");
		}
	}

	public static void validateAmount(double rechargeAmount ) throws AccountException {
		if(rechargeAmount<=0) {
			throw new AccountException("Enter Valid Amount");
		}
	}
}
