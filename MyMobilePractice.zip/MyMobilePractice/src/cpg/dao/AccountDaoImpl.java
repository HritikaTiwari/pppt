package cpg.dao;

import java.util.HashMap;
import java.util.Map;

import cpg.bean.Account;
import cpg.exception.AccountException;

public class AccountDaoImpl implements AccountDao {

	Map<String,Account>accountEntry;
	public AccountDaoImpl(){
		accountEntry= new HashMap<String , Account>();
		accountEntry.put("9010212312", new Account("Prepaid","Hritika",200));
		accountEntry.put("9010452312", new Account("Prepaid","poonam",100));
		accountEntry.put("8880212312", new Account("Postpaid","Vaibhav",200));
		accountEntry.put("7890212312", new Account("Prepaid","satish",500));
		accountEntry.put("9010212987", new Account("Postpaid","mansi",200));
	}
	
	
	


	@Override
	public Account getAccountDetails(String mobileNo) {
		
		Account account = accountEntry.get(mobileNo);
		
		return account;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountException {
		Account account = accountEntry.get(mobileNo);
		if (account == null) {
			throw new AccountException("No account found for " + mobileNo);
		}
		double newBalance = account.getAccountBalance() + rechargeAmount;
		account.setAccountBalance(newBalance);
		return (int) newBalance;
	}

}
