package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;
 

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO{
	
	
//Map for FlatOwner
 Map<Integer ,FlatOwner> owners=new HashMap<Integer,FlatOwner>();
public Map<Integer,FlatOwner> getObject(){
 owners.put(1,new FlatOwner(1,"Vaishali","9023002122"));
 owners.put(2,new FlatOwner(2,"Megha","9643221234"));
 owners.put(3,new FlatOwner(3,"Manish","5453221234"));
return owners;
}

//Map for FlatRegistrationDetails
public static Map<Integer ,FlatRegistrationDTO> flatDetails=new HashMap<Integer,FlatRegistrationDTO>();

//FlatRegistrationDAO content
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
	flatDetails.put(flat.getoID(),flat);
//	    owners.get(flat.getoID());
	
		return flat;
	}
	
	
//	public ArrayList<Integer> getAllOwnerIds(ArrayList<Integer> owId) {
//		// TODO Auto-generated method stub
//
//		FlatOwner bean = owners.get(owId);
//		return owId;
//	}
//
//	@Override
//	public ArrayList<FlatRegistrationDTO> getFlatDetails() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		getObject();
		ArrayList al=new  ArrayList<>(owners.keySet());
		
		return al;
	}


	public  FlatRegistrationDTO getregisterFlat(int resId) {
		// TODO Auto-generated method stub
		FlatRegistrationDTO flat = (FlatRegistrationDTO)flatDetails.get(resId);
		//System.out.println(flat);
		return flat;
	}

}
