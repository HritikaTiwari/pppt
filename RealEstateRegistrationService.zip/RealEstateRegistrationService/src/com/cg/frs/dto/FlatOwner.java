package com.cg.frs.dto;

public class FlatOwner {
@Override
	public String toString() {
		return "FlatOwner [owId=" + owId + ", oName=" + oName + ", mNo=" + mNo + "]";
	}
private int owId;
private String oName;
private String mNo;
public int getOwId() {
	return owId;
}
public void setOwId(int owId) {
	this.owId = owId;
}
public String getoName() {
	return oName;
}
public void setoName(String oName) {
	this.oName = oName;
}
public String getmNo() {
	return mNo;
}
public void setmNo(String mNo) {
	this.mNo = mNo;
}
public FlatOwner(int owId, String oName, String mNo) {
	super();
	this.owId = owId;
	this.oName = oName;
	this.mNo = mNo;
}

}
