package com.cg.frs.dto;

public class FlatRegistrationDTO {
private int regId;
public int getRegId() {
	return regId;
}
private long fID;
private int bHK; 
private int area; 
private int ramnt;
private int damnt;
//to string
@Override
public String toString() {
	return "FlatRegistrationDTO [fID=" + fID + ", bHK=" + bHK + ", area=" + area + ", ramnt=" + ramnt + ", damnt="
			+ damnt + "]";
}
public long getoID() {
	return fID;
}
public void setoID(int oID) {
	this.fID = oID;
}
public int getbHK() {
	return bHK;
}
public void setbHK(int bHK) {
	this.bHK = bHK;
}
public int getArea() {
	return area;
}
public void setArea(int area) {
	this.area = area;
}
public int getRamnt() {
	return ramnt;
}
public void setRamnt(int ramnt) {
	this.ramnt = ramnt;
}
public int getDamnt() {
	return damnt;
}
public void setDamnt(int damnt) {
	this.damnt = damnt;
}
public FlatRegistrationDTO(long resId, int bHK, int area, int ramnt, int damnt) {
	
	this.fID = resId;
	this.bHK = bHK;
	this.area = area;
	this.ramnt = ramnt;
	this.damnt = damnt;
}
public void setRegId(int resId) {
	this.regId = regId;
	
}


}

