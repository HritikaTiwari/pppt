package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatRegistrationDTO;


public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	FlatRegistrationDAOImpl DaoObj = new FlatRegistrationDAOImpl();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		// TODO Auto-generated method stub
//		int ResId = (int) (Math.random() * 1000);
//		flat.setRegId(ResId);
		FlatRegistrationDTO oID =DaoObj.registerFlat(flat);
		//System.out.println(oID);
		return oID;
		
	}
//for getting owners id
	
	@Override
	public ArrayList<Integer> getAllOwnerIds() {
	ArrayList al=	DaoObj.getAllOwnerIds();
		return al;
	}

//for getting flat registration
	
	
	public FlatRegistrationDTO getregisterFlat(int ResId) {
		
		FlatRegistrationDTO flat = DaoObj.getregisterFlat( ResId);
		return flat;
	}
}
