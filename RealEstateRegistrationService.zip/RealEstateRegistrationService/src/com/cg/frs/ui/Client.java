package com.cg.frs.ui;

import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.FlatRegistrationServiceImpl;


public class Client {
	static FlatRegistrationServiceImpl ips = new FlatRegistrationServiceImpl();
	@SuppressWarnings({ "unused", "resource" })
	
	public static void main(String[] args) {
	
		
		Scanner sc = new Scanner(System.in);
	
		boolean exitFromApp = false;
		while(!exitFromApp) {
			System.out.println("***REAL ESTATE REGISTRATION SERVICE***");
			
			System.out.println("1)REGISTER Flat\n" + 
			                   "2)DISPLAY FLAT REGISTRATION DETAILS\n"+
					           "3)EXIT");
			System.out.println("*******************************************");
			
			
			String dashboardIp = sc.nextLine();
			//sc.nextLine();
	
			
			
			switch(dashboardIp) {
		 	case "1":
		 		//Store Enquiry Details
		 		 System.out.println("Existing Owner IDS Are:-[1,2,3]");
		 		 System.out.println("Please Enter Your Owner ID From Above List ");
		 		 int oID = sc.nextInt();
		 		 sc.nextLine();
		 		 System.out.println("Select Flat Type(1-1BHK, 2-2BHK) :");
		 		 int bHK = sc.nextInt();
		 		 sc.nextLine();
		 		 System.out.println("Enter flat area in sq. ft : ");
		 		 int area = sc.nextInt();
		 		 sc.nextLine();
		 		 System.out.println("Enter desired rent amount : ");
		 		 int ramnt= sc.nextInt();
		 		 sc.nextLine();
		 		 System.out.println("Enter desired deposit amount : ");
		 		 int damnt= sc.nextInt();
		 		 sc.nextLine();
		 		
		 			
		 	
			     
		 	
		 		 
//		 		 //Registration Id 
		 		 long ResId = (long) (Math.random() * 1000);
		 		 System.out.println("--------------------------------------------------------------");
		 		FlatRegistrationDTO flat = new FlatRegistrationDTO(ResId,bHK , area ,ramnt, damnt);
		 		 System.out.println(ips.registerFlat(flat));
		 		 System.out.println("Flat successfully registered.\nRegistration Id is "+ResId);
			     System.out.println("Thank You ! Have a nice day");
			     break;
		 	case "2":
		 		 System.out.println("Enter the Registration Id : ");
		 		 long ResId1= sc.nextLong();
		 		 sc.nextLine();
		 		
		 		
		 		 System.out.println("infoo "+ips.getAllOwnerIds());
		 		 FlatRegistrationDTO obj = ips.getregisterFlat((int)ResId1);
		 		 System.out.println("Flat Details "+ips.getregisterFlat((int) ResId1));
		 		
//                 ArrayList<Integer> bean1 = ips.getAllOwnerIds(ResId1);
//		 		 System.out.println(bean1);
		 		 break;
			case "3":
//		 		//exit from app
		 		 exitFromApp = true;
		 		 System.out.println("Thankyou");
		 		 break;
		 	default:
		 		System.out.println("enter valid input");
		}
	
	
		
}

	
}

	private static void flat() {
		// TODO Auto-generated method stub
		
	}

}
