import { TestBed } from '@angular/core/testing';

import { MerchantoperationService } from './merchantoperation.service';

describe('MerchantoperationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MerchantoperationService = TestBed.get(MerchantoperationService);
    expect(service).toBeTruthy();
  });
});
