import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
feed:any;
  constructor(private service:MyserviceService) { }


  ngOnInit() {
    let feed1=this.service.fetch();
    feed1.subscribe(data=>this.feed=data);
  }

}
