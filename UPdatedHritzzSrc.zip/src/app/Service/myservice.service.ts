import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) {
    this.fetch();
   }
   
   fetched:boolean=false;
   fetch(){
    return this.http.get("../../assets/feed.json");
 }
}
