import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../Entity/Product';
import { Category } from '../Entity/Category';
@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  http:HttpClient;
  product:Product[]=[];
  category:Category[]=[];
  constructor(http:HttpClient) {
    this.http=http;
   }
   fetched:boolean=false;
  fetchProduct(){
    this.http.get('./assets/product.json').subscribe(
      data=>{
        if(!this.fetched){
          this.convertProduct(data);
          this.fetched=true;
        }
      }
    );
}
getProduct():Product[]{
  return this.product;
}
convertProduct(data:any){
  for(let o of data["product"]){
    let e=new Product(o.productId,o.productName,o.productDescription,o.productQuantity,o.productPrice);
    this.product.push(e); //fetching details from json class and pushing the value inside table
  }
}
deleteProduct(productId:number){
  let foundIndex:number=-1;
  for(let i=0;i<this.product.length;i++){
    let e=this.product[i];
    if(productId==e.productId){
      foundIndex=i;
      break;

    }
  }
  this.product.splice(foundIndex,1); //To delete the details splice method is used
}
addProduct(e:Product){ //add method is used to add the details
   
  this.product.push(e);
    }
    updateProduct(e:Product){
      for(let i=0;i<this.product.length;i++){
        if(e.productId==this.product[i].productId){
          this.product[i].productName=e.productName;
          this.product[i].productDescription=e.productDescription;
          this.product[i].productQuantity=e.productQuantity;
          this.product[i].productPrice=e.productPrice;
          break;
        }
      }
}


  

   fetchedT:boolean=false;
  fetchCategory(){
    this.http.get('./assets/category.json').subscribe(
      data=>{
        if(!this.fetchedT){
          this.convertCategory(data);
          this.fetchedT=true;
        }
      }
    );
}
getCategory():Category[]
{
  
  return this.category;
}
convertCategory(data:any){
  for(let o of data["category"]){
    let e=new Category(o.categoryId,o.categoryGender,o.categoryType);
    this.category.push(e); //fetching details from json class and pushing the value inside table
  }
}
deleteCategory(categoryId:number){
  let foundIndex:number=-1;
  for(let i=0;i<this.category.length;i++){
    let e=this.category[i];
    if(categoryId==e.categoryId){
      foundIndex=i;
      break;

    }
  }
  this.category.splice(foundIndex,1); //To delete the details splice method is used
}
addCategory(e:Category){ //add method is used to add the details
   
  this.category.push(e);
    }
    updateCategory(e:Category){
      for(let i=0;i<this.category.length;i++){
        if(e.categoryId==this.category[i].categoryId){
          this.category[i].categoryGender=e.categoryGender;
          this.category[i].categoryType=e.categoryType;
         
          break;
        }
      }
}
}




