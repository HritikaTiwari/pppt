import { Injectable } from '@angular/core';
import { Merchant } from '../entity/Merchant';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MerchantoperationService {
  http:HttpClient;
  merchant:Merchant[]=[];
  service:MerchantoperationService;
merchantId:number;
  constructor(service:MerchantoperationService,http:HttpClient) { 
    this.service=service;
    this.http=http;
  }
  
  showMerchant():Observable<any>{
    return this.http.get('http://localhost:9676/merchant/showAll');
  }

  add(e:Merchant):Observable<any>{
    return this.http.post("http://localhost:9676/merchant/add",e);

  }
  update(merchantId:number,e:Merchant):Observable<any>{
    return this.http.put("http://localhost:9676/merchant/update/"+merchantId+"/",e);
  }
}
