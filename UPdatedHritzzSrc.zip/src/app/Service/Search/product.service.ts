import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { ProductDetails } from 'src/app/Entity/search/ProductDetails';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  http:HttpClient;
  productData:ProductDetails[]=[];
  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchProductData();
   }
   fetched:boolean=false;
   fetchProductData(){
    this.http.get('./assets/ProductDetails.json')//path for json file
    .subscribe(
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getProductData():ProductDetails[]{
    return this.productData;
  }
  convert(data:any){
    for(let p of data){
      let productDetails=new ProductDetails(p.PRODUCT_ID,p.PRODUCT_DESCRIPTION,p.PRODUCT_DISCOUNT,p.PRODUCT_NAME,p.PRODUCT_PRICE,p.PRODUCT_QUANTITY,p.CATEGORY_CATEGORY_ID,p.MERCHANT_MERCHANT_ID)
   this.productData.push(productDetails);
    }
  }
  search(PRODUCT_NAME:string):ProductDetails[]
  {
    let result:ProductDetails[]=[];
    let o:ProductDetails
    var flag=0;
    for(let i=0;i<this.productData.length;i++)
    {
      o=this.productData[i];
      if(PRODUCT_NAME==o.PRODUCT_NAME)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(PRODUCT_NAME +".....Record Not Found");
    }
    return result;
  }
  }
  

