import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CustomerDetails } from 'src/app/Entity/search/CustomerDetails';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  http:HttpClient;
  customerData:CustomerDetails[]=[];
    constructor(http:HttpClient) {
      this.http=http;
      this.fetchCustomerData();
     }
  
     fetched:boolean=false;
     fetchCustomerData(){
      this.http.get('./assets/CustomerDetails.json')//path for json file
      .subscribe(
        data=>
        {
          if(!this.fetched)
          {
            this.convert(data);
            this.fetched=true;
          }
        }
      );
    }
  getCustomerData():CustomerDetails[]{
    return this.customerData;
  }
  convert(data:any){
    for(let c of data){
      let customerDetails=new CustomerDetails(c.CUSTOMER_ID,c.CUSTOMER_ADDRESS,c.CUSTOMER_ANSWER,c.CUSTOMER_CONTACT_NO,c.CUSTOMER_NAME,c.CUSTOMER_PASSWORD,c.CUSTOMER_QUESTION,c.CUSTOMER_STATUS)
   this.customerData.push(customerDetails);
    }
  }
  search(CUSTOMER_NAME:string):CustomerDetails[]
  {
    let result:CustomerDetails[]=[];
    let o:CustomerDetails
    var flag=0;
    for(let i=0;i<this.customerData.length;i++)
    {
      o=this.customerData[i];
      if(CUSTOMER_NAME==o.CUSTOMER_NAME)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(CUSTOMER_NAME +".....Record Not Found");
    }
    return result;
  }
  }
  