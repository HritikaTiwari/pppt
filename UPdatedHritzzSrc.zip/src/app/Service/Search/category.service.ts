import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CategoryDetails } from 'src/app/Entity/search/CategoryDetails';


@Injectable({
  providedIn: 'root'
})
export class CategoryService {
http:HttpClient;
categoryData:CategoryDetails[]=[];
  constructor(http:HttpClient) {
    this.http=http;
    this.fetchCategoryData();
   }
   fetched:boolean=false;
   fetchCategoryData(){
    this.http.get('./assets/CategoryDetails.json')//path for json file
    .subscribe(
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getCategoryData():CategoryDetails[]{
    return this.categoryData;
  }
  convert(data:any){
    for(let c of data){
      let categoryDetails=new CategoryDetails(c.CATEGORY_ID,c.CATEGORY_GENDER,c.CATEGORY_TYPE)
   this.categoryData.push(categoryDetails);
    }
  }
  search(CATEGORY_TYPE:string):CategoryDetails[]
  {
    let result:CategoryDetails[]=[];
    let o:CategoryDetails
    var flag=0;
    for(let i=0;i<this.categoryData.length;i++)
    {
      o=this.categoryData[i];
      if(CATEGORY_TYPE==o.CATEGORY_TYPE)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(CATEGORY_TYPE +".....Record Not Found");
    }
    return result;
  }
  }
  
