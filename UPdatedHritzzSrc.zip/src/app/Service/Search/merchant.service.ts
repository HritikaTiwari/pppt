import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MerchantDetails } from 'src/app/Entity/search/MerchantDetails';


@Injectable({
  providedIn: 'root'
})
export class MerchantService {
  http:HttpClient;
  merchantData:MerchantDetails[]=[];
    constructor(http:HttpClient) {
      this.http=http;
      this.fetchMerchantData();
     }
     fetched:boolean=false;
     fetchMerchantData(){
      this.http.get('./assets/MerchantDetails.json')//path for json file
      .subscribe(
        data=>
        {
          if(!this.fetched)
          {
            this.convert(data);
            this.fetched=true;
          }
        }
      );
    }
    getMerchantData():MerchantDetails[]{
      return this.merchantData;
    }
    convert(data:any){
      for(let m of data){
        let merchantDetails=new MerchantDetails(m.MERCHANT_ID,m.MERCHANT_ANSWER,m.MERCHANT_COMPANY_NAME,m.MERCHANT_CONTACT_NO,m.MERCHANT_DISCOUNT,m.MERCHANTGSTNO,m.MERCHANT_NAME,m.MERCHANT_PASSWORD,m.MERCHANT_QUESTION,m.MERCHANT_STATUS)
        this.merchantData.push(merchantDetails);
      }
     
    }
    search(MERCHANT_NAME:string):MerchantDetails[]
    {
      let result:MerchantDetails[]=[];
      let o:MerchantDetails
      var flag=0;
      
      for(let i=0;i<this.merchantData.length;i++)
      {
        o=this.merchantData[i];
        if(MERCHANT_NAME==o.MERCHANT_NAME)
        {
          result.push(o);
          flag=1;
        }
        
      }
      if(flag==0)
      {
        alert(MERCHANT_NAME +".....Record Not Found");
      }
      return result;
    }
    }
