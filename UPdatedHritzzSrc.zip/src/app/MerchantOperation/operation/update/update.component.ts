import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/entity/Merchant';
import { MerchantoperationService } from 'src/app/service/merchantoperation.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  merchant:Merchant;
  service:MerchantoperationService;
  constructor(service:MerchantoperationService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  update(data:any)
  {
    this.merchant = new Merchant(data.merchantId,data.merchantName,data.merchantPassword,data.merchantContactNo,
      data.merchantGSTNo,data.merchantCompanyName,data.merchantStatus,data.merchantDiscount,data.merchantQuestion,data.merchantAnswer);
      var sahu =this.service.update(data.merchantId,this.merchant);
      sahu.subscribe((data) =>{
        console.log(data)
        alert("Updated successfully for merchant ID "+data.merchantId);
      })
  }
}


