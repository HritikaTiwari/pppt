 import { Component, OnInit } from '@angular/core';
 import { Merchant } from 'src/app/entity/Merchant';
 import { MerchantoperationService } from 'src/app/service/merchantoperation.service';

 @Component({
   selector: 'app-show',
  templateUrl: './show.component.html',
   styleUrls: ['./show.component.css']
 })
export class ShowComponent implements OnInit {

 
   merchant:Merchant[]=[];
   service:MerchantoperationService;

  constructor(service:MerchantoperationService) { 
    this.service=service;
 
    this.showMerchant();
     }
  showMerchant(){
    var mini = this.service.showMerchant();
    mini.subscribe((data)=>{
      this.merchant=data
      console.log(this.merchant)
    })
  }
  ngOnInit() {
  }

 }
