import { Component, OnInit } from '@angular/core';
import { MerchantoperationService } from 'src/app/service/merchantoperation.service';
import { Merchant } from 'src/app/entity/Merchant';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  merchant:Merchant;
  service:MerchantoperationService;
  constructor(service:MerchantoperationService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  add(data:any)
  {
    this.merchant = new Merchant(0,data.merchantName,data.merchantPassword,data.merchantContactNo,
      data.merchantGSTNo,data.merchantCompanyName,data.merchantStatus,data.merchantDiscount,data.merchantQuestion,data.merchantAnswer);
      var sahu =this.service.add(this.merchant);
      sahu.subscribe( (data) => {
        console.log(data)
        alert("Added Succesfully!!! Merchant Id is : "+data.merchantId);
      })
  }
}
