import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountAndPromosComponent } from './discount-and-promos.component';

describe('DiscountAndPromosComponent', () => {
  let component: DiscountAndPromosComponent;
  let fixture: ComponentFixture<DiscountAndPromosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiscountAndPromosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscountAndPromosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
