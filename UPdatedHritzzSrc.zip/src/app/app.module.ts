import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InteractionComponent } from './Interaction/interaction/interaction.component';
import {FormsModule, ReactiveFormsModule} from '@Angular/Forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AddComponent } from './MerchantOperation/operation/add/add.component';
import { ShowComponent } from './MerchantOperation/operation/show/show.component';
import { DeleteComponent } from './MerchantOperation/operation/delete/delete.component';
import { UpdateComponent } from './MerchantOperation/operation/update/update.component';
import { HomepageComponent } from './MerchantOperation/homepage/homepage/homepage.component';
import { AdminCouponComponent } from './Coupon/admin-coupon/admin-coupon.component';
import { FrontPageComponent } from './ProductOperation/FrontPage/front-page/front-page.component';
import { ProductComponent } from './ProductOperation/operation/product/product.component';
import { AddProductComponent } from './ProductOperation/operation/add-product/add-product.component';
import { UpdateProductComponent } from './ProductOperation/operation/update-product/update-product.component';
import { CategoryComponent } from './ProductOperation/operation/category/category.component';
import { AddCategoryComponent } from './ProductOperation/operation/add-category/add-category.component';
import { UpdateCategoryComponent } from './ProductOperation/operation/update-category/update-category.component';
import { FirstPageComponent } from './SearchOperation/FirstPage/first-page/first-page.component';
import { CustomerSearchComponent } from './SearchOperation/operation/customer-search/customer-search.component';
import { MerchantSearchComponent } from './SearchOperation/operation/merchant-search/merchant-search.component';
import { ProductSearchComponent } from './SearchOperation/operation/product-search/product-search.component';
import { CategorySearchComponent } from './SearchOperation/operation/category-search/category-search.component';
import { FeedpageComponent } from './FeedBack/FeedPage/feedpage/feedpage.component';
import { FeedbackComponent } from './Service/feedback/feedback.component';
import { ForwardComponent } from './feedback/operation/forward/forward.component';
import { NotForwardComponent } from './feedback/operation/not-forward/not-forward.component';


@NgModule({
  declarations: [
    AppComponent,
    InteractionComponent,
    HomepageComponent,
    AddComponent,
    ShowComponent,
    DeleteComponent,
    UpdateComponent,
    AdminCouponComponent,
    FrontPageComponent,

    ProductComponent,
    AddProductComponent,
    UpdateProductComponent,
    CategoryComponent,
    AddCategoryComponent,
    UpdateCategoryComponent,
    FirstPageComponent,

    CustomerSearchComponent,
    MerchantSearchComponent,
    ProductSearchComponent,
    CategorySearchComponent,
    FeedpageComponent,
    FeedbackComponent,
    ForwardComponent,
    NotForwardComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
   

  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
