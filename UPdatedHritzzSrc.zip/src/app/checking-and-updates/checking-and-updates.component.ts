import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checking-and-updates',
  templateUrl: './checking-and-updates.component.html',
  styleUrls: ['./checking-and-updates.component.css']
})
export class CheckingAndUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
