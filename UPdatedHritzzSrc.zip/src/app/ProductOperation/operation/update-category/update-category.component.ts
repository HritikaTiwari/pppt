import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { ProductServiceService } from 'src/app/Service/product-service.service';
@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {
  createdCategory:Category;

  createdFlag:boolean=false;

  service:ProductServiceService;
  constructor(service:ProductServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  updateCategory(data:any){
    this.createdCategory=new Category(data.categoryId,data.categoryGender,data.categoryType);
    this.service.updateCategory(this.createdCategory);
    this.createdFlag=true;
   }
}
