import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { ProductServiceService } from 'src/app/Service/product-service.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  createdProduct:Product;
  createdFlag:boolean=false;
  service: ProductServiceService;
  constructor(service: ProductServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  addProduct(data:any){  //This method is used to add the details 
    this.createdProduct=new
    Product(data.productId,data.productName,data.productDescription,data.productQuantity,data.productPrice);
    this.service.addProduct(this.createdProduct); 

    this.createdFlag=true;
  }
}
