import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from 'src/app/Service/product-service.service';
import { Category } from 'src/app/Entity/Category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  service:ProductServiceService;
  constructor(service:ProductServiceService) {
    this.service=service;
   }
   category:Category[]=[];
   deleteCategory(categoryId:number){            
     this.service.deleteCategory(categoryId);
     this.category=this.service.getCategory();
   }
  ngOnInit() {
    this.service.fetchCategory();
    this.category=this.service.getCategory();
   
  }

}
