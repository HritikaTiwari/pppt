import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from 'src/app/Service/product-service.service';
import { Product } from 'src/app/Entity/Product';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  service:ProductServiceService;
  constructor(service:ProductServiceService) { 
    this.service=service;
  }

  product:Product[]=[];
deleteProduct(productId:number){            
  this.service.deleteProduct(productId);
  this.product=this.service.getProduct();
}
  ngOnInit() {
    this.service.fetchProduct();
    this.product=this.service.getProduct();
  }

}
