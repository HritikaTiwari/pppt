import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { ProductServiceService } from 'src/app/Service/product-service.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
  createdProduct:Product;

  createdFlag:boolean=false;

  service:ProductServiceService;
  constructor(service:ProductServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  updateProduct(data:any){
    this.createdProduct=new Product(data.productId,data.productName,data.productDescription,data.productQuantity,data.productPrice);
    this.service.updateProduct(this.createdProduct);
    this.createdFlag=true;
   }
}
