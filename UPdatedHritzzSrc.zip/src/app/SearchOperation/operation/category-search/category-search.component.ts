import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/Service/Search/category.service';
import { CategoryDetails } from 'src/app/Entity/search/CategoryDetails';


@Component({
  selector: 'app-category-search',
  templateUrl: './category-search.component.html',
  styleUrls: ['./category-search.component.css']
})
export class CategorySearchComponent implements OnInit {
service:CategoryService;

  constructor(service:CategoryService) {
    this.service=service;
   }
categoryData:CategoryDetails[]=[];
  ngOnInit() {
    this.service.fetchCategoryData();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let name:string=data.CATEGORY_TYPE;
    this.categoryData=this.service.search(name);
  }
}
