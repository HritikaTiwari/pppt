import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/Service/Search/product.service';
import { ProductDetails } from 'src/app/Entity/search/ProductDetails';


@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
service:ProductService;
  constructor(service:ProductService) 
  {
    this.service=service;
   }
productData:ProductDetails[]=[];

  ngOnInit() {
    this.service.fetchProductData();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let name:string=data.PRODUCT_NAME;
    this.productData=this.service.search(name);
  }
}
