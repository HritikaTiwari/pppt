import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/Service/Search/customer.service';
import { CustomerDetails } from 'src/app/Entity/search/CustomerDetails';


@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.css']
})
export class CustomerSearchComponent implements OnInit {
service:CustomerService;
  constructor(service:CustomerService)
   {
     this.service=service;
    }
customerData:CustomerDetails[]=[];
  ngOnInit() {
    this.service.fetchCustomerData();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let name:string=data.CUSTOMER_NAME;
    this.customerData=this.service.search(name);
  }
}
