import { Component, OnInit } from '@angular/core';
import { MerchantService } from 'src/app/Service/Search/merchant.service';
import { MerchantDetails } from 'src/app/Entity/search/MerchantDetails';


@Component({
  selector: 'app-merchant-search',
  templateUrl: './merchant-search.component.html',
  styleUrls: ['./merchant-search.component.css']
})
export class MerchantSearchComponent implements OnInit {
service:MerchantService;

  constructor(service:MerchantService) {
    this.service=service;
   }
merchantData:MerchantDetails[]=[];
  ngOnInit() {
    this.service.fetchMerchantData();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let name:string=data.MERCHANT_NAME;
    this.merchantData=this.service.search(name);
    
  }
}
