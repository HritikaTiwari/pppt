import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managing-cart',
  templateUrl: './managing-cart.component.html',
  styleUrls: ['./managing-cart.component.css']
})
export class ManagingCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
