export class Product{
    productId:number;
    productName:string;
    productDescription:string;
    productQuantity:number;
    productPrice:number;
    constructor( productId:number,
      productName:string,
      productDescription:string,
      productQuantity:number,
      productPrice:number){
        this.productId=productId;
        this.productName=productName;
        this.productDescription=productDescription;
        this.productQuantity=productQuantity;
        this.productPrice=productPrice;
      }
  
  }