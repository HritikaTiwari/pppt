export class CategoryDetails{
    CATEGORY_ID:number;
    CATEGORY_GENDER:string;
    CATEGORY_TYPE:string;
   
        constructor( CATEGORY_ID:number,CATEGORY_GENDER:string,CATEGORY_TYPE:string)
        {
          this.CATEGORY_ID=CATEGORY_ID;
          this.CATEGORY_GENDER=CATEGORY_GENDER;
          this.CATEGORY_TYPE=CATEGORY_TYPE;
          
        }
    }